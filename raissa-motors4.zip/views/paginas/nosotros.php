<div class="fondo-info small-fondo">
    <div class="fondo-frase">
        <div class="frase">
            <h2>Conoce más sobre nuestra Historia</h2>
        </div>
    </div>
    
</div>



<div class="contenedor-nosotros">
    <h2>Nosotros</h2>
    <div class="caja-nosotros">
        <img src="../imagenes/TIENDA.jpg" alt="">
        <div class="info">
            <p>Somos una Empresa con más de 18 años en el Mercado Nacional, dedicada a la fabricación de Mototaxis, Cargueros, Motocicletas. Contamos con personal altamente calificado con autorización del Ministerio de Producción.</p>
            <p>Con sucursal en Barranca, Puente Piedra, Comas y con Distribuidores a nivel Nacional como Chimbote, Trujillo, Casma, Barranca. </p>
            <p>RaissaMotors inicio en el año 2003 con venta de repuestos para vehiculos menores en el distrito del Rimac, años después nos mudamos a la Av 22 de agosto en el Mercado Modelo, iniciando con la fabricación de Mototaxis.</p>
        </div>
        <div class="info">
            <p>Somos una Empresa con más de 18 años en el Mercado Nacional, dedicada a la fabricación de Mototaxis, Cargueros, Motocicletas. Contamos con personal altamente calificado con autorización del Ministerio de Producción.</p>
            <p>Con sucursal en Barranca, Puente Piedra, Comas y con Distribuidores a nivel Nacional como Chimbote, Trujillo, Casma, Barranca. </p>
            <p>RaissaMotors inicio en el año 2003 con venta de repuestos para vehiculos menores en el distrito del Rimac, años después nos mudamos a la Av 22 de agosto en el Mercado Modelo, iniciando con la fabricación de Mototaxis.</p>
        </div>
        <img src="../imagenes/TIENDA.jpg" alt="">
    </div>


    <div class="mvo">
        <h3>Misión</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Non nisi tenetur consectetur numquam repellat? Blanditiis, minima quisquam magnam maxime dicta excepturi autem quidem officia perferendis ratione inventore veritatis ad facilis.</p>
        <h3>Visión</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut animi totam dicta consectetur sequi architecto repudiandae et. Quibusdam error, accusamus aliquid quis molestiae iusto veritatis ab corrupti pariatur repellat officiis.</p>
        <h3>Objetivo</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia velit aliquid ab quam dolore excepturi, blanditiis perferendis perspiciatis vitae corporis ullam. Optio quia magni animi odio alias quisquam dolor nisi!</p>
    </div>
</div>

