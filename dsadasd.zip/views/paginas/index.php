<div class="fondo-info">
    
</div>

<div class="contenedor-nosotros">
    <h2 class="nosotros-titulo">Sobre Nosotros</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id nostrum, praesentium ducimus quae quaerat minima pariatur corporis possimus debitis aut explicabo blanditiis hic est voluptas doloribus nihil? Deleniti, labore officia.</p>
    <div class="nosotros-info">
        <div class="info-caja">
            <i class='bx bx-cycling'></i>
            <h3>Motos</h3>
            <p>Motos de primera calidad y elegancia</p>
        </div>
        <div class="info-caja">
            <i class='bx bx-cycling'></i>
            <h3>Motos</h3>
            <p>Motos de primera calidad y elegancia</p>
        </div>
        <div class="info-caja">
            <i class='bx bx-cycling'></i>
            <h3>Motos</h3>
            <p>Motos de primera calidad y elegancia</p>
        </div>
    </div>
</div>

<div class="ver-mas-nosotros">
    <a href="" class="btn-nosotros">Ver más sobre Nosotros</a>
</div>

<div class="contenedor">
    <div class="contenedor-productos">
        <h2 class="titulo-productos">Nuestros Productos</h2>
        <div class="productos-caja">
            <div class="producto">
                <h3 class="producto-info">Motocicletas</h3>
                <a href="">Ver más Motocicletas</a>
                <img src="../imagenes/chopper.png" alt="">
            </div>
            <div class="producto">
                <h3 class="producto-info">Motocicletas</h3>
                <a href="">Ver más Motocicletas</a>
                <img src="../imagenes/chopper.png" alt="">
            </div>
            <div class="producto">
                <h3 class="producto-info">Motocicletas</h3>
                <a href="">Ver más Motocicletas</a>
                <img src="../imagenes/chopper.png" alt="">
            </div>
        </div>
    </div>
</div>