<?php

function conectarDB() : mysqli{
    $db = new mysqli("localhost", "root", "root","raissamo_bd1");

    if(!$db){
        echo "Error no se pudo conectar";
        exit;
    }

    return $db;
}
