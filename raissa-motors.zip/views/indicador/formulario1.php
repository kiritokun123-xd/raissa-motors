<label for="upd-date">Fecha:</label>
<input type="date" id="upd-date" name="indicador1[fecha]" value="<?php echo s($indicador1->fecha); ?>">

<label for="upd-ven-acu">Venta Acumulada:</label>
<input type="number" id="new-ven-acu" name="indicador1[ven_acumulada]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador1->ven_acumulada); ?>">

<label for="upd-ven-acu">Inventario Inicial:</label>
<input type="number" step="0.01" id="new-ven-acu" name="indicador1[inv_inicial]" placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador1->inv_inicial); ?>">

<label for="upd-ven-acu">Inventario Entrante:</label>
<input type="number" step="0.01" id="new-ven-acu" name="indicador1[inv_entrante]" placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador1->inv_entrante); ?>">

<label for="upd-ven-acu">Inventario Final:</label>
<input type="number" step="0.01" id="new-ven-acu" name="indicador1[inv_final]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador1->inv_final); ?>">

<label for="upd-ven-acu">Promedio de Inventario:</label>
<input type="number" step="0.01" id="new-ven-acu"  name="indicador1[inv_prom]" placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador1->inv_prom); ?>">

<label for="upd-ven-acu">Índice:</label>
<input type="number" step="0.01" id="new-ven-acu"  name="indicador1[rot_mercancia]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador1->rot_mercancia); ?>">


