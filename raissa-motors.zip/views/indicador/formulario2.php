<label for="upd-date">Fecha:</label>
<input type="date" id="upd-date" name="indicador2[fecha]" value="<?php echo s($indicador2->fecha); ?>">

<label for="upd-ven-acu">Venta Acumulada:</label>
<input type="number" id="new-ven-acu" name="indicador2[ven_acumulada]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->ven_acumulada); ?>">
<label for="upd-ven-acu">Costo de Servicios:</label>
<input type="number" id="new-ven-acu" name="indicador2[servicios]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->servicios); ?>">

<label for="upd-ven-acu">Costo de Alquiler:</label>
<input type="number" step="0.01" id="new-ven-acu" name="indicador2[alquiler]" placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->alquiler); ?>">

<label for="upd-ven-acu">Costo Personal:</label>
<input type="number" step="0.01" id="new-ven-acu" name="indicador2[personal]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->personal); ?>">

<label for="upd-ven-acu">Costo del Almacén:</label>
<input type="number" step="0.01" id="new-ven-acu"  name="indicador2[cost_alm]" placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->cost_alm); ?>">

<label for="upd-ven-acu">Costo Unidad:</label>
<input type="number" step="0.01" id="new-ven-acu"  name="indicador2[cost_uni]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->cost_uni); ?>">

<label for="upd-ven-acu">Índice:</label>
<input type="number" step="0.01" id="new-ven-acu"  name="indicador2[cost_uni_alm]"  placeholder="Ingrese la Venta Acumulada" value="<?php echo s($indicador2->cost_uni_alm); ?>">


