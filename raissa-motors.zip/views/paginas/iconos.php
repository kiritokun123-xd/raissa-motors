<div class="iconos-nosotros">
    <div class="icono">
        <img src="build/img/icono1.svg" alt="Icono Seguridad" loading="lazy">
        <h3>Seguridad</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae non alias nostrum nesciunt explicabo excepturi incidunt unde similique? Necessitatibus at repellendus blanditiis animi minima aspernatur doloremque? Vel, quisquam iure. In!</p>
    </div>
    <div class="icono">
        <img src="build/img/icono2.svg" alt="Icono Precio" loading="lazy">
        <h3>Precio</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae non alias nostrum nesciunt explicabo excepturi incidunt unde similique? Necessitatibus at repellendus blanditiis animi minima aspernatur doloremque? Vel, quisquam iure. In!</p>
    </div>
    <div class="icono">
        <img src="build/img/icono3.svg" alt="Icono Tiempo" loading="lazy">
        <h3>Tiempo</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae non alias nostrum nesciunt explicabo excepturi incidunt unde similique? Necessitatibus at repellendus blanditiis animi minima aspernatur doloremque? Vel, quisquam iure. In!</p>
    </div>
</div>