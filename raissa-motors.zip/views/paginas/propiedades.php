<main class="contenedor seccion">
    <h2>Casas y Depas en Venta</h2>
    <?php 
    include 'listado.php'; 
    ?>
</main>